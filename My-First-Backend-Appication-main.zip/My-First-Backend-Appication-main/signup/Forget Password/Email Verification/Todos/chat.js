console.log("Chat Page Connected");


import { db, app } from "../../../../firebase-config.js";
import {
    getAuth,
    signOut,
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/9.10.0/firebase-auth.js";

import {
    collection,
    addDoc,
    Timestamp,
    query,
    where,
    onSnapshot,
    doc,
    deleteDoc,
    updateDoc,
    orderBy,
    documentId
} from "https://www.gstatic.com/firebasejs/9.10.0/firebase-firestore.js";

// checking user is signing or not
const auth = getAuth(app);
onAuthStateChanged(auth, (user) => {
    let loader = document.getElementById("loader");
    let hide = document.getElementById("hide")
    if (user) {
        fetchusersData()
        const uid = user.uid;
    } else {
        console.log("User is signed out")
        return false;
    }
});





let ul = document.querySelector(".userList")
async function fetchusersData() {
    let dataRef = collection(db, "users");
    let condition = where("uid", "!=", auth.currentUser.uid);
    const q = query(dataRef, condition);
    onSnapshot(q, (querySnapshot) => {
        querySnapshot.forEach((doc) => {
            // getId = doc.id
            ul.innerHTML += `<li onClick="userdataonclick('${doc.data().uid}')" style="margin="5px">
               <img width="50px";height="50px"; src="${doc.data().dpURL}" />
               ${doc.data().userName}
               <p>${doc.data().email}</p>
                </li>`

        });

    })
}


let chatBox = document.querySelector(".chatBox");

function userdataonclick(id) {

    // localStorage.setItem("userinfo", id);

    let dataRef = collection(db, "users");
    let condition = where("uid", "==", id);
    const q = query(dataRef, condition);
    onSnapshot(q, (querySnapshot) => {
        querySnapshot.forEach((doc) => {
            chatBox.innerHTML = "";
            chatBox.innerHTML += `<div onClick="userdataonclick('${doc.data().uid}')" style="margin="5px">
               <img width="50px";height="50px"; src="${doc.data().dpURL}" />
               ${doc.data().userName}
               <p>${doc.data().email}</p>
                </div>`

        });

    })
}



let msg = document.querySelector("#msg");
let send = document.querySelector("#send");

send.addEventListener("click", chatMsg)

function chatMsg() {

    console.log(msg.value,);


    

}




window.userdataonclick = userdataonclick;