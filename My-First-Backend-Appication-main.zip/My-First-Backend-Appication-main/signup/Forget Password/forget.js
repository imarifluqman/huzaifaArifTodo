// import {app} from "../../firebase-config.js"
// import { getAuth, updatePassword } from "https://www.gstatic.com/firebasejs/9.10.0/firebase-auth.js";

// const auth = getAuth(app);


// const user = auth.currentUser;
// const newPassword = getASecureRandomPassword();

// updatePassword(user, newPassword).then(() => {
//   // Update successful.
// }).catch((error) => {
//   // An error ocurred
//   // ...
// });
// let submit = document.getElementById("submit-data");
// submit.addEventListener("click",getASecureRandomPassword)